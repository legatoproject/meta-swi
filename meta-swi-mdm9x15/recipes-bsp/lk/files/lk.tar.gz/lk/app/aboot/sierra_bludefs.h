/************
 * $Id$
 *
 * Filename:  bludefs.h
 *
 * Purpose:   external definitions for BL package
 *
 * NOTES:
 *
 * Copyright: � 2010 - 2012 Sierra Wireless, Inc.
 *            All rights reserved
 *
 ************/

#ifndef bludefs_h
#define bludefs_h

#define BS_BOOT_APP_MSG_START              (MSM_SHARED_BASE + 0x100000 - 0x1020)
#define BS_BOOT_APP_MSG_STARTMARKER        BS_BOOT_APP_MSG_START
#define BS_BOOT_APP_MSG_FLAGS              (BS_BOOT_APP_MSG_START + 24)
#define BS_BOOT_APP_MSG_ENDMARKER          (BS_BOOT_APP_MSG_START + 28)
#define BC_VALID_BOOT_MSG_MARKER           0xBABECAFEU   /* indicates message from Boot to App */
#define BC_MSG_MARKER_M                    0xFFFF0000U
#define BCBOOTAPPFLAG_UPDATE_PENDING_M     0x00000001
#define BCBOOTAPPFLAG_ADB_ENABLE_M         0x00000004

#define BC_PKGDESC_MAXSIZE          1536

#define BL_DLOAD_BASE               0x41800000
#define BL_DLOAD_SPKG_CB_START      BL_DLOAD_BASE
#define BL_DLOAD_SPKG_CB_SIZE       0x1000
#define BL_SPKG_CB_MAGIC_NUM1       0x53504B47  /* SPKG */
#define BL_SPKG_CB_MAGIC_NUM2       0x474B5053  /* SPKG */
#define BL_SIMG_CB_MAGIC_NUM1       0x53494D47  /* SIMG */
#define BL_SIMG_CB_MAGIC_NUM2       0x474D4953  /* SIMG */
#define BL_SPKG_TEST_SKU_NUM        9999999
#define BL_MAX_NUM_IMAGE            16
#define BL_SIMG_CB_MAX_PART_SIZE    8

/* FW Update results */
#define BC_FW_DLOADED               0x00000000
#define BC_FW_UPDATED_OK            0x00000001
#define BC_FW_UPDATE_FALED          0xFFFFFFFF

#define BL_DLOAD_START_ADDR         (BL_DLOAD_BASE + BL_DLOAD_SPKG_CB_SIZE)
#define BL_DLOAD_AREA_SIZE          (BL_DLOAD_SIZE - BL_DLOAD_SPKG_CB_SIZE)

#define DLOAD_MAGIC_NUM_1           0xE47B337D
#define DLOAD_MAGIC_NUM_2           0xCE14091A


/* structures */

/*************
 *
 * Name:     blimagecb
 *
 * Purpose:  Structure of image update status control block for a single image
 *
 * Members:
 *           part               : partition name
 *           start_address      : start address in RAM (downloaded image)
 *           image_size         : image size
 *           image_crc          : image crc32
 *           status             : Image update status and other flags:
 *                                - 0x00: BLIMG_DLOADED - downloaded and pending update
 *                                - 0x01: BLIMG_UPDATED_OK - applied OK
 *                                - 0xFF: BLIMG_UPDATED_FALED - update FAILED
 *           image_type         : type of the image (as shown in bcimagetype)
 *           reserved           : reserved for future use
 *
 * Notes:    This structure has the fixed size of 32 byte
 *
 **************/
struct __PACKED blimagecb
{
  uint8_t                 part[BL_SIMG_CB_MAX_PART_SIZE];
  uint8_t                 *start_address;
  uint32_t                image_size;  
  uint32_t                image_crc;  
  uint32_t                status;
  uint8_t                 image_type;
  uint8_t                 reserved[7];
};

/*************
 *
 * Name:     blspkgcbs
 *
 * Purpose:  Structure of Sierra package download control block
 *
 * Members:
 *           magic_1            : magic number 1 (SPKG)
 *           imagebufp          : SPKG CWE image buffer pointer
 *           imgsize            : total size of SPKG CWE image
 *           imgoffset          : current image offset (from beginning of SPKG CWE hdr)
 *           compnum            : current component number
 *           reserved           : reserved
 *           magic_2            : magic number 2, end of structure (SPKG)
 *           imgcb_magic_1      : magic number for image update status (SIMG)
 *           imgupdatestatus    : image update status for each image
 *           imgcb_magic_2      : magic number ofr image update status (SIMG)
 *
 * Notes:    max possible structure size is BL_DLOAD_SPKG_CB_SIZE. This structure is
 *           placed at the fix RAM location at BL_DLOAD_SPKG_CB_START 
 *
 **************/
struct __PACKED blspkgcbs
{
  uint32_t                magic_1;
  uint8_t                 *imagebufp;
  uint32_t                imgsize;  
  int32_t                 imgoffset;
  uint16_t                compnum;
  uint8_t                 reserved[234];
  uint8_t                 pkgdesc[BC_PKGDESC_MAXSIZE];
  uint32_t                magic_2;
  uint32_t                imgcb_magic_1;
  struct blimagecb        imgupdatestatus[BL_MAX_NUM_IMAGE];
  uint32_t                imgcb_magic_2;
};

extern void sierra_bl_flash_pending_linux_images(void);
extern bool sierra_is_infastboot(void);
extern bool sierra_is_fastboot_disabled(void);
extern uint32_t sierra_crcrc32(uint8_t *address, uint32_t size);

#endif /* bludefs_h */
