/************
 *
 * $Id$
 *
 * Filename:  sierra_bl.c
 *
 * Purpose:   Sierra Little Kernel changes            
 *
 * Copyright: � 2012 Sierra Wireless, Inc.
 *            All rights reserved
 *
 * Note:       
 *
 ************/

#include <string.h>
#include <reg.h>
#include <debug.h>
#include <platform.h>
#include <platform/iomap.h>
#include <arch/ops.h>

#include "sierra_bludefs.h"

/*
 *  externs
 */
extern bool cmd_flash(const char *arg, void *data, unsigned sz);


/*
 *  Local variables
 */
static bool sierra_infastboot = true;
static uint32_t sierra_b2aflags = 0;

/* 
 * Local functions 
 */

/************
 *
 * Name:     blpkggcb
 *
 * Purpose:  Get package control block pointer
 *
 * Parms:    none
 *
 * Return:   control block pointer
 *
 * Abort:    none
 *
 * Notes:    none
 *
 ************/
static struct blspkgcbs *blpkggcb(
  void )
{
  return (struct blspkgcbs *)BL_DLOAD_SPKG_CB_START;  
}

/************
 *
 * Name:     blpkgimgcbvalid
 *
 * Purpose:  check if package control block is valid
 *
 * Parms:    none
 *
 * Return:   TRUE if image update control block valid, 
 *           FALSE otherwise
 *
 * Abort:    none
 *
 * Notes:    none
 *
 ************/
static bool blpkgimgcbvalid(
  void )
{
  struct blspkgcbs *blpkgcbp = blpkggcb();

  if(blpkgcbp->imgcb_magic_1 == BL_SIMG_CB_MAGIC_NUM1 &&
     blpkgcbp->imgcb_magic_2 == BL_SIMG_CB_MAGIC_NUM2)
  {
    return true;
  }
  else
  {
    return false;
  }
}

/************
 *
 * Name:     sierra_is_fastboot_disabled
 *
 * Purpose:  check if fastboot disabled
 *
 * Parms:    none
 *
 * Return:   TRUE - if disabled
 *           FALSE - otherwise
 *
 * Abort:    none
 *
 * Notes:    none
 *
 ************/
bool sierra_is_fastboot_disabled(
  void)
{
  return (sierra_b2aflags & BCBOOTAPPFLAG_ADB_ENABLE_M) ? false : true;
}

/************
 *
 * Name:     sierra_set_b2aflags
 *
 * Purpose:  set local copy of b2aflags
 *
 * Parms:    none
 *
 * Return:   none
 *
 * Abort:    none
 *
 * Notes:    none
 *
 ************/
static void sierra_set_b2aflags(
  uint32_t flags)
{
  sierra_b2aflags = flags;
}

/************
 *
 * Name:     sierra_set_infastboot
 *
 * Purpose:  set the flag to indicate whether the device is in fast boot
 *           and fast boot host link connection is present
 *
 * Parms:    none
 *
 * Return:   none
 *
 * Abort:    none
 *
 * Notes:    none
 *
 ************/
static void sierra_set_infastboot(
  bool mode)
{
  sierra_infastboot = mode;
}

/************
 *
 * Name:     sierra_is_infastboot
 *
 * Purpose:  get the flag to inidicate whether if the device is in fast boot
 *           and fast boot host link connection is present
 *
 * Parms:    none
 *
 * Return:   TRUE - in fastboot mode and fastboot usb link is present
 *           FALSE otherwise
 *
 * Abort:    none
 *
 * Notes:    none
 *
 ************/
bool sierra_is_infastboot(
  void)
{
  return sierra_infastboot;
}

/************
 *
 * Name:     sierra_bl_flash_pending_linux_images
 *
 * Purpose:  flsh pending Linux images
 *
 * Parms:    none
 *
 * Return:   none
 *
 * Abort:    none
 *
 * Notes:    none
 *
 ************/
void sierra_bl_flash_pending_linux_images(
  void)
{
  struct blspkgcbs *blpkgcbp = blpkggcb();
  struct blimagecb* entryp;
  uint32_t entry;
  bool result, need_update, need_reboot = false;
  uint32_t b2aflags;
  char partname[BL_SIMG_CB_MAX_PART_SIZE + 1];

  /* first check Sierra SMEM b2a flags to see if pending update */
  if((readl(BS_BOOT_APP_MSG_STARTMARKER) & BC_MSG_MARKER_M) == (BC_VALID_BOOT_MSG_MARKER & BC_MSG_MARKER_M) &&
     (readl(BS_BOOT_APP_MSG_ENDMARKER) & BC_MSG_MARKER_M) == (BC_VALID_BOOT_MSG_MARKER & BC_MSG_MARKER_M))   
  {
    b2aflags = readl(BS_BOOT_APP_MSG_FLAGS);
    sierra_set_b2aflags(b2aflags);
    if(b2aflags & BCBOOTAPPFLAG_UPDATE_PENDING_M)
    {
      /* only continue if set, otherwise could not access downloaded images
       * since the regions will be locked for Sparrow processor
       */
      dprintf(INFO, "SWI - pending image update\n");

    }
    else
    {
      /* no pending updates, return */
      return;
    }
  }
  else
  {
    /* no valid flag marker, return */
    return;
  }

  if(blpkgimgcbvalid())
  {
    /* set update mode - no fastboot host present */
    sierra_set_infastboot(false);
    
    for(entry = 0; entry < BL_MAX_NUM_IMAGE; entry ++)
    {
      entryp = &blpkgcbp->imgupdatestatus[entry];
      if(entryp->part[0] != 0 &&
         entryp->start_address != 0 &&
         entryp->image_size != 0 &&
         entryp->status == BC_FW_DLOADED)
      {
        /* examine if it is a Linux partition */
        if(!strncmp((char *)entryp->part, "APPS", BL_SIMG_CB_MAX_PART_SIZE))
        {
          /* write Linux kernel */
          strcpy(partname, "boot");
          need_update = true;
        }
        else if(!strncmp((char *)entryp->part, "SYSTEM", BL_SIMG_CB_MAX_PART_SIZE))
        {
          /* write Linux root fs */
          strcpy(partname, "system");
          need_update = true;
        }
        else if(!strncmp((char *)entryp->part, "USERDATA", BL_SIMG_CB_MAX_PART_SIZE))
        {
          /* write Linux partition */
          strcpy(partname, "userdata");
          need_update = true;
        }
        else if(!strncmp((char *)entryp->part, "HDATA", BL_SIMG_CB_MAX_PART_SIZE))
        {
          /* write Linux partition */
          strcpy(partname, "hdata");
          need_update = true;
        }
        else
        {
          /* not update */
          need_update = false;
        }
        
        if(need_update)
        {
          /* check image crc32 first
           * Note that the CRC check takes long time:
           * for USERDATA partition: CRC check 7s, flash time 3s
           * SWI_TBD BD 120425 need to find a fast crc32 algorithm
           */
          if(entryp->image_crc != sierra_crcrc32(entryp->start_address, entryp->image_size))
          {
            dprintf(INFO, "SWI - image CRC check failed \n");
            result = false; 
          }
          else
          {
            result = cmd_flash(partname, 
                               entryp->start_address, 
                               entryp->image_size);
            
          }
          
          if(result)
          {
            entryp->status = BC_FW_UPDATED_OK;
          }
          else
          {
            entryp->status = BC_FW_UPDATE_FALED;
            break;
          }
          need_reboot = true;
        } /* end if updated */
        
      } /* end if need update */
    } /* end for entry */

    /* set update mode back */
    sierra_set_infastboot(true);
 
    if(need_reboot)
    {
      /* last image update status will not be written without this cache sync */       
      arch_sync_cache_range((void *)&blpkgcbp->imgupdatestatus[0], 
                            sizeof(blpkgcbp->imgupdatestatus));
      /* need reboot */
      reboot_device(0);
    }

  } /* end if valid fw update cb */
}
